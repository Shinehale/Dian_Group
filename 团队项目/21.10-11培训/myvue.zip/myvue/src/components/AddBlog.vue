<template>
  <div class="add-blog">
    <h2>添加博客</h2>
    <form v-show="submitted">
      <label>博客标题</label>
      <input type="text"v-model="blog.title" required />
      <label>博客内容 </label>
      <textarea v-model="blog.content"></textarea>
      <div id="checkbox">
        <label>Vue.js</label>
        <input type="checkbox" name="" v-model="blog.categories" value="Vue.js" />
        <label>Node.js</label>
        <input type="checkbox" name="" v-model="blog.categories" value="Node.js" />
        <label>React.js</label>
        <input type="checkbox" name="" v-model="blog.categories" value="React.js" />
        <label>Angular4</label>
        <input type="checkbox" name="" v-model="blog.categories" value="Angular4" />
        <label></label>
      </div>
      <label>文章出处:</label>
      <select v-model="blog.author">
        <option v-for="authors in authors">{{authors}}</option>
      </select>
      <button type="button" @click="ppost"> 添加博客</button>
    </form>
    <div v-show="!submitted">
      <h3>您的博客发发布成功!</h3>
    </div>
    <div id="preview" v-show="!submitted">
      <h3>博客总览</h3>
      <p>博客标题:{{blog.title}}</p>
      <p>博客内容:</p>
      <p>{{blog.content}}</p>
    </div>
  </div>
</template>

<script>
  import axios from 'vue-axios'
  export default{
    name:'add-blog',
    data(){
      return {
        blog:{
          title:"",
          content:"",
          categories:[],
          author:""
        },
        authors:['原创','转载'],
        submitted:1
      }
    },
    methods:{
      ppost: function(){
        axios.post('url',blog).then(function(response){
          console.log(response);
          this.submitted=false;
        },function(err){ })
        //记得最后把成功的现实渲染到页面上.
      }
    }
  }
</script>

<style scoped>
.add-blog * {
  box-sizing: border-box;
}
.add-blog{
  margin: 20px auto;
  padding: 20px;
  max-width: 600px;
}
label{
  display: block;
  margin: 20px 0 10px;
  font-size: 20px;
  font-family: Youyuan;
}
input[type="text"],textarea,select{
  width: 100%;
  padding: 8px;
  border-radius: 25px;
}
#checkbox label{
  display: inline-block;
  margin-top: 0;
}
#checkbox input {
  display: inline-block;
  margin-right: 10px;
}
button {
  display: block;
  margin: 20px 0;
  background: crimson;
  color: beige;
  border: 0;
  padding: 14px;
  border-radius: 25px;
  font-size: 18px;
  cursor: pointer;
	width: 100px;
	height: 50px;
}
#preview  {
  padding:10px 20px;
  border: 1px dotted #ccc;
  margin: 30px 0;
  border-radius: 15px;
}#preview h3 {
  margin-top: 10px;
}
textarea {
  width: 100%;
  height: 500px;
  border-radius: 25px;
}
.add-blog h2 {
  text-align: center;
  font-size: 30px;
}
select {
  font-size: 20px
}
option {
  font-size: 20px;
}
</style>
