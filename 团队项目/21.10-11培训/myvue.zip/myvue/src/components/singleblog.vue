<template>
  <div id="singleblog">
    <h1>{{blog.title}}</h1>
    <article>{{blog.body}}</article>
    <p>来源:{{blog.author}}</p>
    <p>分类:</p>
    <ul>
      <li v-for="category in blog.categories">
        {{category}}
      </li>
    </ul>
    <button type="button" >删除</button>
    <router-link :to="'/edit/'+this.id">
      <button type="button">编辑</button>
    </router-link>
  </div>
</template>

<script>
import Vue from 'vue'
import axios from 'axios'
import vueAxios from 'vue-axios'
export default {
  name: 'singleblog',
  data(){
    return{
        id:this.$route.params.id,
        blog:{}
    }
  },
  created() {
    let that =this
    axios.get("http://jsonplaceholder.typicode.com/posts/"+that.id).then(function(data){
        that.blog=data.data
    },function(error){})
  },
  methods:{
    delete:function(){
      // axios.delete("http://jsonplaceholder.typicode.com/posts/"+that.id).then(function(res){
      //   this.$router.push({path:'/'})
      //   console.log(res);

      // }).catch(function(err){

      // })
    }
  }
}
</script>

<style scoped>
  *{
    font-family: Youyuan;
  }
  #singleblog{
    max-width: 960px;
    margin: 0 auto;
    padding: 20px;
    background-color: white;
    border: 1px dotted #aaa;
    border-radius: 20px;
    box-shadow: 0 15px 25px rgba(94, 88, 5, 0.5);
  }
  #singleblog h1 {
    text-align: left;
    font-family: Youyuan;
  }
  button{
    width: 50px;
    border: none;
    height: 30px;
    border-radius: 20px;
    background-color: rgba(21, 229, 229, 0.2);
    margin-right: 10px;
    font-weight: 500;
  }
  p {
    margin: 10px;
  }
</style>
